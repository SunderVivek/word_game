def word_game(board, word)
	solution = []
	word.split('').each { |letter|
	position_from_left = board.find_index(letter)
	position_from_right = board.reverse.find_index(letter)
	optimum_position = [position_from_left, position_from_right].min
	if letter == board[optimum_position]
		board.rotate!(optimum_position)
		optimum_position.times {solution << "LEFT"}
		removed_letter = board.shift
		solution << "LEFT :#{removed_letter}"
	else
		board.rotate!(-optimum_position)
		optimum_position.times {solution << "RIGHT"}
		removed_letter = board.pop
		solution << "RIGHT :#{removed_letter}"
	end
}
	return solution.join(", ")
end
