require './lib/word_game'  

describe 'word_game' do
	it 'returns correct order for a board array and word' do
	    expect(word_game([ 'a', 'z', 'c', 't', 'v', 'a' ], "cat")).to eq "LEFT, LEFT, LEFT :c, RIGHT, RIGHT :a, LEFT, LEFT :t"
	end
end